//A program that calculates monthly payment, commission, closing cost, and average annual increases and decreases.
import java.util.*;
public class BuyingAHouse
{
    public static double calMonthlyPayment (double amountBorrowed, double interestRate, double loanInMonths)//Method for calculating the montly payment.
    {
        interestRate = ((interestRate/100)/12);
        double monthlyPayment = ((amountBorrowed*interestRate)/(1-(Math.pow(1/(1+interestRate), loanInMonths))));
        return monthlyPayment;
    }
    
    public static double calCommission (double commissionRate, double purchasePrice)//Method for calculating commissions.
    {
        commissionRate = commissionRate / 100;
        double commission = purchasePrice * commissionRate;
        return commission;
    }
    
    public static double calClosingCost (double myPurchasePrice, double myDownPayment, double myRate)//Method for calculating closing cost.
    {
        myRate = myRate / 100;
        double closingCost;
        closingCost = (myPurchasePrice - myDownPayment) * myRate;
        return closingCost;
    }
    
    public static double geometricMean(double rate1, double rate2)//Closing cost method with 2 parameters.
    {
        rate1 = rate1 / 100 + 1;
        rate2 = rate2 / 100 + 1;
        double twoParameters;
        twoParameters = Math.pow(rate1 * rate2, (double)1/3) * 100 - 100;
        return twoParameters;
    }
    
    public static double geometricMean(double rate1, double rate2, double rate3)//Closing cost method with 3 parameters.
    {
        rate1 = rate1 / 100 + 1;
        rate2 = rate2 / 100 + 1;
        rate3 = rate3 / 100 + 1;
        double threeParameters;
        threeParameters = Math.pow(rate1 * rate2 * rate3, (double)1/3) * 100 - 100;
        return threeParameters;
    }
    
    public static double geometricMean(double rate1, double rate2, double rate3, double rate4)//Closing cost method with 4 parameters.
    {
        rate1 = rate1 / 100 + 1;
        rate2 = rate2 / 100 + 1;
        rate3 = rate3 / 100 + 1;
        rate4 = rate4 / 100 + 1;
        double fourParameters;
        fourParameters = Math.pow(rate1 * rate2 * rate3 * rate4, (double)1/3) * 100 - 100;
        return fourParameters;
    }
    
    public static double geometricMean(double rate1, double rate2, double rate3, double rate4, double rate5)//Closing cost method with 5 parameters.
    {
        rate1 = rate1 / 100 + 1;
        rate2 = rate2 / 100 + 1;
        rate3 = rate3 / 100 + 1;
        rate4 = rate4 / 100 + 1;
        rate5 = rate5 / 100 + 1;
        double fiveParameters;
        fiveParameters = Math.pow(rate1 * rate2 * rate3 * rate4 * rate5, (double)1/3) * 100 - 100;
        return fiveParameters;
    }

    public static double geometricMean(double rate1, double rate2, double rate3, double rate4, double rate5, double rate6)//Closing cost method with 6 parameters.
    {
        rate1 = rate1 / 100 + 1;
        rate2 = rate2 / 100 + 1;
        rate3 = rate3 / 100 + 1;
        rate4 = rate4 / 100 + 1;
        rate5 = rate5 / 100 + 1;
        rate6 = rate6 / 100 + 1;
        double sixParameters;
        sixParameters = Math.pow(rate1 * rate2 * rate3 * rate4 * rate5 * rate6, (double)1/3) * 100 - 100;
        return sixParameters;
    }
    
    public static void main (String [] args)
    {
        Scanner input = new Scanner (System.in);
        
        double userAmountBorrowed, userInterestRate, userLoanInMonths, userMonthlyPayment;//Variables for calculated monthly payment.
        double userCommission, userPurchasePrice, finalCommission;//Variables for calculated comission.
        double myPurchasePrice, myDownPayment, myRate, myClosingCost;//Variables for calculated closing cost.
        double check, rate1, rate2, rate3, rate4, rate5, rate6;//Variables for calculating averages.
        double mean1, mean2, mean3, mean4, mean5, mean6;
        int choice;  //Variable for while loop.
        
        System.out.println("Welcome To Buying A House!");
        System.out.println("What option would you like to see?");
        System.out.print("Press 1 for Monthly Payment.  Press 2 for Commission.  Press 3 for Closing Cost.  Press 4 for Average Increases and Decreases.  Press 5 to Exit. ");
        choice = input.nextInt();  //Scanner for entering the loop.
        
        do
        {
            while (choice == 1)//Calling for monthly payment method.
            {
                System.out.println("");
                
                System.out.print("How much do you want to borrow: ");
                userAmountBorrowed = input.nextDouble();
        
                System.out.print("What is the interest on the loan: ");
                userInterestRate = input.nextDouble();
        
                System.out.print("How many months do you plan to finance this loan: ");
                userLoanInMonths = input.nextDouble();
        
                userMonthlyPayment = calMonthlyPayment (userAmountBorrowed, userInterestRate, userLoanInMonths);
                System.out.println("Your monthly payment is " + userMonthlyPayment + ".");
            
                System.out.println("");
            
                System.out.println("What else would you like to do?");
                System.out.print("Press 1 for Monthly Payment.  Press 2 for Commission.  Press 3 for Closing Cost.  Press 4 for Average Increases and Decreases.  Press 5 to Exit. ");
                choice = input.nextInt();
            }
        
            while (choice == 2)//Calling for commission method.
            {
                System.out.println("");
                
                System.out.print("How much do you want to borrow: ");
                userPurchasePrice = input.nextDouble();
        
                System.out.print("What is the commission rate: ");
                userCommission = input.nextDouble();
            
                finalCommission = calCommission (userCommission, userPurchasePrice);
                System.out.println("The commission rate is " + finalCommission + ".");
            
                System.out.println("");
            
                System.out.println("What else would you like to do?");
                System.out.print("Press 1 for Monthly Payment.  Press 2 for Commission.  Press 3 for Closing Cost.  Press 4 for Average Increases and Decreases.  Press 5 to Exit. ");
                choice = input.nextInt();
            }
            
            while (choice == 3)//Calling for closing cost method.
            {
                System.out.println("");
                
                System.out.print("How much do you want to borrow: ");
                myPurchasePrice = input.nextDouble();
        
                System.out.print("What is the down payment: ");
                myDownPayment = input.nextDouble();
        
                System.out.print("What is the rate of the closing cost: ");
                myRate = input.nextDouble();
        
                myClosingCost = calClosingCost(myPurchasePrice, myDownPayment, myRate);
                System.out.println("Your closing cost is " + myClosingCost + ".");
            
                System.out.println("");
            
                System.out.println("What else would you like to do?");
                System.out.print("Press 1 for Monthly Payment.  Press 2 for Commission.  Press 3 for Closing Cost.  Press 4 for Average Increases and Decreases.  Press 5 to Exit. ");
                choice = input.nextInt();
            }
            
            while(choice == 4)//Calling for average method.
            {
                System.out.println("");
                
                int count = 1;
                System.out.print("How many years do you want to check: ");
                check = input.nextInt();
                
                if (check == 2)//Calls for two parameters.
                {
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate1 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate2 = input.nextDouble();
                    
                    mean2 = geometricMean(rate1, rate2);
                    if (mean2 >= 0)
                    {
                        System.out.println("The home's value after " + count + " annual changes of " + rate1 + "% " + " and " + rate2 + "%" + " is increased by " + mean2 + "%.");
                    }
                    else
                    {
                        System.out.println("The home's value after " + count + " annual changes of " + rate1 + "% " + " and " + rate2 + "%" + " is decreased by " + mean2 + "%.");
                    }
                }
                
                if (check == 3)//Calls for three parameters.
                {
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate1 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate2 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate3 = input.nextDouble();
                    
                    mean3 = geometricMean(rate1, rate2, rate3);
                    if (mean3 >= 0)
                    {
                        System.out.println("The home's value after " + count + " annual changes of " + rate1 + "%, " + rate2 + "%, and " + rate3 + "%" + " is increased by " + mean3 + "%.");
                    }
                    else
                    {
                        System.out.println("The home's value after " + count + " annual changes of " + rate1 + "%, " + rate2 + "%, and " + rate3 + "%" + " is decreased by " + mean3 + "%.");
                    }
                }
                
                if (check == 4)//Calls for four parameters.
                {
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate1 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate2 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate3 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate4 = input.nextDouble();
                    
                    mean4 = geometricMean(rate1, rate2, rate3, rate4);
                    if (mean4 >= 0)
                    {
                        System.out.println("The home's value after " + count + " annual changes of " + rate1 + "%, " + rate2 + "%, " + rate3
                        + "%, and " + rate4 + "%" + " is increased by " + mean4 + "%.");
                    }
                    else
                    {
                        System.out.println("The home's value after " + count + " annual changes of " + rate1 + ", " + rate2 + ", " + rate3
                        + "%, and " + rate4 + "%" + " is decreased by " + mean4 + "%.");
                    }
                }
                
                if (check == 5)//Calls for five parameters.
                {
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate1 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate2 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate3 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate4 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate5 = input.nextDouble();
                    
                    mean5 = geometricMean(rate1, rate2, rate3, rate4, rate5);
                    if (mean5 >= 0)
                    {
                        System.out.println("The home's value after " + count + " annual changes of " + rate1 + "%, " + rate2 + "%, " + rate3 + "%, " + rate4 + "%, and " + rate5 + "%" + " is increased by " + mean5 + "%.");
                    }
                    else
                    {
                        System.out.println("The home's value after " + count + " annual changes of " + rate1 + "%, " + rate2 + "%, " + rate3 + "%, " + rate4 + "%, and " + rate5 + "%" + " is decreased by " + mean5 + "%.");
                    }
                }
                
                if (check == 6)//Calls for six parameters.
                {
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate1 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate2 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate3 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate4 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate5 = input.nextDouble();
                    count++;
                    
                    System.out.print("What is the interest rate for year " + count + " : ");
                    rate6 = input.nextDouble();
                    
                    mean6 = geometricMean(rate1, rate2, rate3, rate4, rate5, rate6);
                    if (mean6 >= 0)
                    {
                        System.out.println("The home's value after " + count + " annual changes of " + rate1 + "%, " + rate2 + "%, " + rate3 + "%, " + rate4 + "%, " + rate5 + "%, and " + rate6 + "%" + " is increased by " + mean6 + "%.");
                    }
                    else
                    {
                        System.out.println("The home's value after " + count + " annual changes of " + rate1 + "%, " + rate2 + "%, " + rate3 + "%, " + rate4 + "%, " + rate5 + "%, and " + rate6 + "%" + " is decreased by " + mean6 + "%.");
                    }
                }
                
                System.out.println("");
            
                System.out.println("What else would you like to do?");
                System.out.print("Press 1 for Monthly Payment.  Press 2 for Commission.  Press 3 for Closing Cost.  Press 4 for Average Increases and Decreases.  Press 5 to Exit. ");
                choice = input.nextInt();
            }
        } while (choice != 5); //Exits program.
    }
}
